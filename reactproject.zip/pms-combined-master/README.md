# pms-combined
Placement Management system DBMS project

Placement management system is a DBMS Full stack project built using React.js,Node.js,MySQL

# Frontend 
Reactjs
Material-ui
CSS

# Backend
Node.js
Express.js

# Databases
MySQL
